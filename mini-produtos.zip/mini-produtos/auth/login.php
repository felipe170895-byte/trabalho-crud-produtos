<?php
require_once __DIR__ . '/../config/session.php';
require __DIR__ . '/../config/db.php';

$erro = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
  $email = trim($_POST['email'] ?? '');
  $senha = $_POST['senha'] ?? '';
  if ($email === '' || $senha === '') {
    $erro = 'Informe e-mail e senha.';
  } else {
    $hash = hash('sha256', $senha);
    $st = $pdo->prepare('SELECT id, nome, email FROM usuarios WHERE email = ? AND senha_hash = ?');
    $st->execute([$email, $hash]);
    $u = $st->fetch();
    if ($u) {
      $_SESSION['user_id'] = (int)$u['id'];
      $_SESSION['user_name'] = $u['nome'];
      header('Location: /mini-produtos/app/dashboard.php');
      exit;
    } else {
      $erro = 'E-mail ou senha inválidos.';
    }
  }
}
?>
<!doctype html>
<html lang="pt-br">
<head>
  <meta charset="utf-8">
  <title>Login</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body class="bg-light">
<div class="container py-5" style="max-width:480px">
  <h1 class="mb-4">Login</h1>

  <?php if ($erro): ?><div class="alert alert-danger"><?=htmlspecialchars($erro)?></div><?php endif; ?>

  <form method="post" class="vstack gap-3">
    <input type="email" name="email" class="form-control" placeholder="E-mail" required>
    <input type="password" name="senha" class="form-control" placeholder="Senha" required>
    <button class="btn btn-primary w-100">Entrar</button>
  </form>

  <div class="mt-3">
    <a href="/mini-produtos/auth/register.php">Criar conta</a>
  </div>
</div>
</body>
</html>

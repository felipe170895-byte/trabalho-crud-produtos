<?php
require_once __DIR__ . '/../config/session.php';
require __DIR__ . '/../config/db.php';

$erro = ''; $ok = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
  $nome  = trim($_POST['nome']  ?? '');
  $email = trim($_POST['email'] ?? '');
  $senha = $_POST['senha'] ?? '';
  $conf  = $_POST['confirma'] ?? '';

  if ($nome === '' || $email === '' || $senha === '') {
    $erro = 'Preencha todos os campos.';
  } elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
    $erro = 'E-mail inválido.';
  } elseif ($senha !== $conf) {
    $erro = 'Senha e confirmação não conferem.';
  } else {
    // verifica se já existe
    $st = $pdo->prepare('SELECT 1 FROM usuarios WHERE email = ?');
    $st->execute([$email]);
    if ($st->fetch()) {
      $erro = 'Já existe um usuário com esse e-mail.';
    } else {
      $hash = hash('sha256', $senha); // SHA-256 conforme requisito
      $ins = $pdo->prepare('INSERT INTO usuarios (nome, email, senha_hash) VALUES (?,?,?)');
      $ins->execute([$nome, $email, $hash]);
      $ok = 'Conta criada! Faça login.';
    }
  }
}
?>
<!doctype html>
<html lang="pt-br">
<head>
  <meta charset="utf-8">
  <title>Registrar</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body class="bg-light">
<div class="container py-5" style="max-width:520px">
  <h1 class="mb-4">Criar conta</h1>

  <?php if ($erro): ?><div class="alert alert-danger"><?=htmlspecialchars($erro)?></div><?php endif; ?>
  <?php if ($ok): ?><div class="alert alert-success"><?=htmlspecialchars($ok)?></div><?php endif; ?>

  <form method="post" class="vstack gap-3">
    <input class="form-control" name="nome"  placeholder="Nome" required minlength="2" maxlength="80" value="<?=htmlspecialchars($_POST['nome'] ?? '')?>">
    <input class="form-control" name="email" placeholder="E-mail" type="email" required value="<?=htmlspecialchars($_POST['email'] ?? '')?>">
    <input class="form-control" name="senha" placeholder="Senha" type="password" required>
    <input class="form-control" name="confirma" placeholder="Confirmar senha" type="password" required>
    <button class="btn btn-success w-100">Registrar</button>
  </form>

  <div class="mt-3">
    <a href="/mini-produtos/auth/login.php">Voltar ao login</a>
  </div>
</div>
</body>
</html>

<?php
require dirname(__DIR__, 2) . '/config/api_guard.php';
require dirname(__DIR__, 2) . '/config/db.php';
header('Content-Type: application/json; charset=utf-8');

$sql = 'SELECT id, nome, email, created_at FROM usuarios ORDER BY id DESC';
echo json_encode($pdo->query($sql)->fetchAll());

<?php
require dirname(__DIR__, 2) . '/config/api_guard.php';
require dirname(__DIR__, 2) . '/config/db.php';

$nome = trim($_POST['nome'] ?? '');
$preco = (float)str_replace(',', '.', $_POST['preco'] ?? '0');
$fornecedor_id = (int)($_POST['fornecedor_id'] ?? 0);

if ($nome === '' || mb_strlen($nome) < 2 || mb_strlen($nome) > 120) { http_response_code(422); exit('Nome inválido (2 a 120).'); }
if (!($preco > 0)) { http_response_code(422); exit('Preço deve ser > 0.'); }
if ($fornecedor_id <= 0) { http_response_code(422); exit('Fornecedor inválido.'); }

try {
  require_once dirname(__DIR__, 2) . '/app/models/Fornecedor.php';
  require_once dirname(__DIR__, 2) . '/app/models/Produto.php';
  require_once dirname(__DIR__, 2) . '/app/repositories/ProdutoRepository.php';
  $repo = new ProdutoRepository($pdo);
  $repo->create(new Produto(null, $nome, $preco, new Fornecedor($fornecedor_id,'','',null)));
  echo 'ok';
} catch (Throwable $e) {
  $st = $pdo->prepare('INSERT INTO produtos (nome, preco, fornecedor_id) VALUES (?,?,?)');
  $st->execute([$nome, $preco, $fornecedor_id]);
  echo 'ok';
}

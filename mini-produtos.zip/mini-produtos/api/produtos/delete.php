<?php
require dirname(__DIR__, 2) . '/config/api_guard.php';
require dirname(__DIR__, 2) . '/config/db.php';

$id = (int)($_POST['id'] ?? 0);
if ($id <= 0) { http_response_code(400); exit('ID inválido.'); }

try {
  // OO
  require_once dirname(__DIR__, 2) . '/app/repositories/ProdutoRepository.php';
  $repo = new ProdutoRepository($pdo);
  $repo->delete($id);
  echo 'ok';
} catch (Throwable $e) {
  $st = $pdo->prepare('DELETE FROM produtos WHERE id = ?');
  $st->execute([$id]);
  echo 'ok';
}

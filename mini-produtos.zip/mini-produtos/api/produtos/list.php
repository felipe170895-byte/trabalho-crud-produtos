<?php
require dirname(__DIR__, 2) . '/config/api_guard.php';
require dirname(__DIR__, 2) . '/config/db.php';
header('Content-Type: application/json; charset=utf-8');

try {
  // OO
  require_once dirname(__DIR__, 2) . '/app/repositories/ProdutoRepository.php';
  $repo = new ProdutoRepository($pdo);
  $rows = $repo->all();
  $out = array_map(fn($p)=>[
    'id'=>$p->id, 'nome'=>$p->nome, 'preco'=>$p->preco, 'fornecedor'=>$p->fornecedor->nome
  ], $rows);
  echo json_encode($out);
} catch (Throwable $e) {
  // Procedural (LEFT JOIN para evitar sumir produto “órfão”)
  $sql = 'SELECT p.id, p.nome, p.preco, COALESCE(f.nome,"") AS fornecedor
          FROM produtos p LEFT JOIN fornecedores f ON f.id = p.fornecedor_id
          ORDER BY p.id DESC';
  echo json_encode($pdo->query($sql)->fetchAll());
}

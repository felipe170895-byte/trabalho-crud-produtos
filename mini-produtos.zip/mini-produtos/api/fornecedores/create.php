<?php
require dirname(__DIR__, 2) . '/config/api_guard.php';
require dirname(__DIR__, 2) . '/config/db.php';

$nome = trim($_POST['nome'] ?? '');
$cnpj = preg_replace('/\D+/', '', $_POST['cnpj'] ?? '');
$tel  = preg_replace('/\D+/', '', $_POST['telefone'] ?? '');

if ($nome === '' || mb_strlen($nome) < 3 || mb_strlen($nome) > 120) { http_response_code(422); exit('Nome inválido (3 a 120).'); }
if (!preg_match('/^\d{14}$/', $cnpj)) { http_response_code(422); exit('CNPJ deve ter 14 dígitos.'); }
if ($tel !== '' && !preg_match('/^\d{10,11}$/', $tel)) { http_response_code(422); exit('Telefone 10 ou 11 dígitos.'); }

try {
  require_once dirname(__DIR__, 2) . '/app/models/Fornecedor.php';
  require_once dirname(__DIR__, 2) . '/app/repositories/FornecedorRepository.php';
  $repo = new FornecedorRepository($pdo);
  $repo->create(new Fornecedor(null, $nome, $cnpj, $tel));
  echo 'ok';
} catch (Throwable $e) {
  $st = $pdo->prepare('INSERT INTO fornecedores (nome, cnpj, telefone) VALUES (?,?,?)');
  $st->execute([$nome, $cnpj, $tel]);
  echo 'ok';
}

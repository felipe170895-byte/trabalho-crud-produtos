<?php
require dirname(__DIR__, 2) . '/config/api_guard.php';
require dirname(__DIR__, 2) . '/config/db.php';

header('Content-Type: application/json; charset=utf-8');

try {
  require_once dirname(__DIR__, 2) . '/app/repositories/FornecedorRepository.php';
  $repo = new FornecedorRepository($pdo);
  $rows = $repo->all();
  $out = array_map(fn($f)=>[
    'id'=>$f->id, 'nome'=>$f->nome, 'cnpj'=>$f->cnpj, 'telefone'=>$f->telefone
  ], $rows);
  echo json_encode($out);
} catch (Throwable $e) {
  $rows = $pdo->query('SELECT id, nome, cnpj, telefone FROM fornecedores ORDER BY id DESC')->fetchAll();
  echo json_encode($rows);
}

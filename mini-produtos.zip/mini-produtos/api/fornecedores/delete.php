<?php
require dirname(__DIR__, 2) . '/config/api_guard.php';
require dirname(__DIR__, 2) . '/config/db.php';

$id = (int)($_POST['id'] ?? 0);
if ($id <= 0) { http_response_code(400); exit('ID inválido.'); }

try {
  require_once dirname(__DIR__, 2) . '/app/repositories/FornecedorRepository.php';
  $repo = new FornecedorRepository($pdo);
  $repo->delete($id);
  echo 'ok';
} catch (Throwable $e) {
  try {
    $st = $pdo->prepare('DELETE FROM fornecedores WHERE id = ?');
    $st->execute([$id]);
    echo 'ok';
  } catch (PDOException $ex) {
    http_response_code(409);
    exit('Não é possível excluir: há produtos vinculados a este fornecedor.');
  }
}

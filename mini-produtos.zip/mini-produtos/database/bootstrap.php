<?php

ini_set('display_errors', 1);
error_reporting(E_ALL);

$DB_HOST='127.0.0.1';
$DB_NAME='mini_produtos';
$DB_USER='root';
$DB_PASS='';

try {
  $pdo0 = new PDO("mysql:host=$DB_HOST;charset=utf8mb4", $DB_USER, $DB_PASS, [
    PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION
  ]);
} catch (PDOException $e) {
  exit('Falha ao conectar no MySQL: ' . $e->getMessage());
}

$pdo0->exec("CREATE DATABASE IF NOT EXISTS `$DB_NAME` CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci");

try {
  $pdo = new PDO("mysql:host=$DB_HOST;dbname=$DB_NAME;charset=utf8mb4", $DB_USER, $DB_PASS, [
    PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
    PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
    PDO::ATTR_EMULATE_PREPARES => false
  ]);
} catch (PDOException $e) {
  exit('Erro de conexão ao DB: ' . $e->getMessage());
}

$pdo->exec("
CREATE TABLE IF NOT EXISTS usuarios (
  id INT AUTO_INCREMENT PRIMARY KEY,
  nome VARCHAR(80) NOT NULL,
  email VARCHAR(120) NOT NULL UNIQUE,
  senha_hash CHAR(64) NOT NULL,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS fornecedores (
  id INT AUTO_INCREMENT PRIMARY KEY,
  nome VARCHAR(120) NOT NULL,
  cnpj VARCHAR(20) NOT NULL,
  telefone VARCHAR(20),
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS produtos (
  id INT AUTO_INCREMENT PRIMARY KEY,
  nome VARCHAR(120) NOT NULL,
  preco DECIMAL(10,2) NOT NULL,
  fornecedor_id INT NOT NULL,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  CONSTRAINT fk_prod_for FOREIGN KEY (fornecedor_id)
    REFERENCES fornecedores(id)
    ON UPDATE CASCADE ON DELETE RESTRICT
);
");

// 5) (Opcional) cria um usuário admin se não existir
$adminEmail = 'admin@exemplo.com';
$adminNome  = 'Administrador';
$adminSenha = 'admin123'; // mude depois!
$hash = hash('sha256', $adminSenha);

$st = $pdo->prepare("SELECT id FROM usuarios WHERE email=?");
$st->execute([$adminEmail]);
if (!$st->fetch()) {
  $ins = $pdo->prepare("INSERT INTO usuarios (nome,email,senha_hash) VALUES (?,?,?)");
  $ins->execute([$adminNome, $adminEmail, $hash]);
  $msgAdmin = "Usuário admin criado: $adminEmail / senha: $adminSenha";
} else {
  $msgAdmin = "Usuário admin já existia: $adminEmail";
}

echo "<h2>Bootstrap OK!</h2>";
echo "<p>Banco/tabelas verificados/criados.</p>";
echo "<p>$msgAdmin</p>";
echo '<p><a href="/mini-produtos/auth/login.php">Ir para o Login</a></p>';

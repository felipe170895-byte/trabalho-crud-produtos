<?php
require_once __DIR__ . '/session.php';
if (empty($_SESSION['user_id'])) {
  http_response_code(401);
  header('Content-Type: application/json; charset=utf-8');
  echo json_encode(['error' => 'Não autenticado']);
  exit;
}

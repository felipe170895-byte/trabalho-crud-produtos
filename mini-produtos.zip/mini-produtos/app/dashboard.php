<?php
require_once __DIR__ . '/../config/session.php';
require_login();
?>
<!doctype html>
<html lang="pt-br">
<head>
  <meta charset="utf-8">
  <title>Bem Vindo</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body class="p-4">
  <?php include __DIR__ . '/partials/navbar.php'; ?>
  <div class="container">
    <h1>Bem Vindo</h1>
    <p><?=htmlspecialchars($_SESSION['user_nome'] ?? '')?></p>
    <a class="btn btn-outline-secondary" href="../auth/logout.php">Sair</a>
  </div>
</body>
</html>

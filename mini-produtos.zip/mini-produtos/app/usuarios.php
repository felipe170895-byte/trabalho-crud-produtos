<?php
require_once __DIR__ . '/../config/session.php';
require_login();
?>
<!doctype html>
<html lang="pt-br">
<head>
  <meta charset="utf-8">
  <title>Usuários</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>
<?php include __DIR__ . '/partials/navbar.php'; ?>
<div class="container py-4">
  <h1 class="mb-3">Usuários</h1>
  <table class="table table-striped" id="tbl">
    <thead><tr><th>ID</th><th>Nome</th><th>E-mail</th><th>Criado em</th></tr></thead>
    <tbody></tbody>
  </table>
</div>

<script>
(async function carregar(){
  const r = await fetch('../api/usuarios/list.php');
  if (!r.ok){ alert('Falha ao listar usuários ('+r.status+'): '+await r.text()); return; }
  const data = await r.json();
  const tb = document.querySelector('#tbl tbody');
  tb.innerHTML = '';
  for (const u of data){
    tb.innerHTML += `<tr>
      <td>${u.id}</td>
      <td>${u.nome}</td>
      <td>${u.email}</td>
      <td>${u.created_at ?? ''}</td>
    </tr>`;
  }
})();
</script>
</body>
</html>

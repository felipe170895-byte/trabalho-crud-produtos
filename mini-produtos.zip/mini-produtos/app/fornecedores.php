<?php
require_once __DIR__ . '/../config/session.php';
require_login();
?>
<!doctype html>
<html lang="pt-br">
<head>
  <meta charset="utf-8">
  <title>Fornecedores</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
</head>
<body>
<?php include __DIR__ . '/partials/navbar.php'; ?>

<div class="container py-4">
  <h1 class="mb-3">Fornecedores</h1>

  <!-- Formulário com validação -->
  <form id="formFor" class="row g-2 mb-3" novalidate>
    <div class="col-md-5">
      <input class="form-control" name="nome" placeholder="Nome"
             required minlength="3" maxlength="120">
      <div class="invalid-feedback">Informe um nome (mín. 3 caracteres).</div>
    </div>

    <div class="col-md-3">
      <input class="form-control" name="cnpj" placeholder="CNPJ (somente números)"
             required pattern="^\d{14}$" inputmode="numeric">
      <div class="invalid-feedback">CNPJ deve ter 14 dígitos.</div>
    </div>

    <div class="col-md-3">
      <input class="form-control" name="telefone" placeholder="Telefone (opcional)"
             pattern="^\d{10,11}$" inputmode="numeric">
      <div class="invalid-feedback">Telefone deve ter 10 ou 11 dígitos (DDD + número).</div>
    </div>

    <div class="col-md-1 d-grid">
      <button class="btn btn-primary">OK</button>
    </div>
  </form>

  <table class="table table-striped" id="tbl">
    <thead>
      <tr>
        <th>ID</th>
        <th>Nome</th>
        <th>CNPJ</th>
        <th>Telefone</th>
        <th>Ações</th>
      </tr>
    </thead>
    <tbody></tbody>
  </table>
</div>

<script>
const URL_LIST   = '../api/fornecedores/list.php';
const URL_CREATE = '../api/fornecedores/create.php';
const URL_DELETE = '../api/fornecedores/delete.php';

async function carregar(){
  const r = await fetch(URL_LIST);
  if (!r.ok) { alert('Listagem falhou ('+r.status+'): '+await r.text()); return; }
  const data = await r.json();
  const tb = document.querySelector('#tbl tbody');
  tb.innerHTML = '';
  for (const f of data){
    tb.innerHTML += `<tr>
      <td>${f.id}</td><td>${f.nome}</td><td>${f.cnpj}</td><td>${f.telefone ?? ''}</td>
      <td><button class="btn btn-sm btn-danger" onclick="excluir(${f.id})">Excluir</button></td>
    </tr>`;
  }
}

document.getElementById('formFor').addEventListener('submit', async (e)=>{
  e.preventDefault();
  const form = e.currentTarget;
  if (!form.checkValidity()) { form.classList.add('was-validated'); return; }
  const r = await fetch(URL_CREATE, { method:'POST', body:new FormData(form) });
  if (!r.ok) { alert('Criação falhou ('+r.status+'): '+await r.text()); return; }
  form.reset(); form.classList.remove('was-validated'); carregar();
});

async function excluir(id){
  if (!confirm('Excluir este fornecedor?')) return;
  const fd = new FormData(); fd.append('id', id);
  const r = await fetch(URL_DELETE, { method:'POST', body: fd });
  if (!r.ok) { alert('Exclusão falhou ('+r.status+'): '+await r.text()); return; }
  carregar();
}

carregar();
</script>
</body>
</html>

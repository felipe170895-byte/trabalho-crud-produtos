<?php
require_once __DIR__ . '/../models/Produto.php';
require_once __DIR__ . '/../models/Fornecedor.php';

class ProdutoRepository {
  public function __construct(private PDO $pdo) {}

  public function all(): array {
    $sql = 'SELECT p.id,p.nome,p.preco,
                   f.id as fid,f.nome as fnome,f.cnpj,f.telefone
            FROM produtos p
            JOIN fornecedores f ON f.id = p.fornecedor_id
            ORDER BY p.id DESC';
    $rows = $this->pdo->query($sql)->fetchAll();

    return array_map(function($r){
      $for = new Fornecedor((int)$r['fid'],$r['fnome'],$r['cnpj'],$r['telefone']);
      return new Produto((int)$r['id'],$r['nome'],(float)$r['preco'],$for);
    }, $rows);
  }

  public function create(Produto $p): int {
    $st = $this->pdo->prepare('INSERT INTO produtos (nome,preco,fornecedor_id) VALUES (?,?,?)');
    $st->execute([$p->nome, $p->preco, $p->fornecedor->id]);
    return (int)$this->pdo->lastInsertId();
  }

  public function delete(int $id): void {
    $st = $this->pdo->prepare('DELETE FROM produtos WHERE id=?');
    $st->execute([$id]);
  }
}

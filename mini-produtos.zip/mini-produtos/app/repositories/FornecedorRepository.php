<?php
require_once __DIR__ . '/../models/Fornecedor.php';

class FornecedorRepository {
  public function __construct(private PDO $pdo) {}

  public function all(): array {
    $rows = $this->pdo->query('SELECT * FROM fornecedores ORDER BY id DESC')->fetchAll();
    return array_map(
      fn($r)=> new Fornecedor((int)$r['id'],$r['nome'],$r['cnpj'],$r['telefone']),
      $rows
    );
  }

  public function create(Fornecedor $f): int {
    $st = $this->pdo->prepare('INSERT INTO fornecedores (nome,cnpj,telefone) VALUES (?,?,?)');
    $st->execute([$f->nome, $f->cnpj, $f->telefone]);
    return (int)$this->pdo->lastInsertId();
  }

  public function delete(int $id): void {
    $st = $this->pdo->prepare('DELETE FROM fornecedores WHERE id=?');
    $st->execute([$id]);
  }

  public function exists(int $id): bool {
    $st = $this->pdo->prepare('SELECT 1 FROM fornecedores WHERE id=?');
    $st->execute([$id]);
    return (bool)$st->fetchColumn();
  }
}

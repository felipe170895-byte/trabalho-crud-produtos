<?php
require_once __DIR__ . '/../config/session.php';
require_login();
require __DIR__ . '/../config/db.php';

$produtos = $pdo->query('SELECT id, nome, preco FROM produtos ORDER BY nome')->fetchAll();

// ao enviar o formulário
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
  $ids = $_POST['prod'] ?? [];         
  if (empty($ids)) {
    $erro = 'Selecione pelo menos um produto.';
  } else {
    $_SESSION['cesta'] = [];
    foreach ($ids as $id) {
      $_SESSION['cesta'][(int)$id] = true;
    }
    header('Location: cesta.php');
    exit;
  }
}
?>
<!doctype html>
<html lang="pt-br">
<head>
  <meta charset="utf-8">
  <title>Selecionar Produtos</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
</head>
<body>
<?php include __DIR__ . '/partials/navbar.php'; ?>
<div class="container py-4">
  <h1 class="mb-3">Selecionar Produtos</h1>

  <?php if (!empty($erro)): ?>
    <div class="alert alert-warning"><?=htmlspecialchars($erro)?></div>
  <?php endif; ?>

  <?php if (count($produtos) === 0): ?>
    <div class="alert alert-info">Não há produtos cadastrados. Cadastre em <a href="produtos.php">Produtos</a>.</div>
  <?php else: ?>
    <form method="post">
      <table class="table table-striped">
        <thead>
          <tr>
            <th style="width:60px;"></th>
            <th>Produto</th>
            <th style="width:180px;">Preço</th>
          </tr>
        </thead>
        <tbody>
          <?php foreach ($produtos as $p): ?>
            <tr>
              <td><input type="checkbox" name="prod[]" value="<?=$p['id']?>"></td>
              <td><?=htmlspecialchars($p['nome'])?></td>
              <td>R$ <?=number_format((float)$p['preco'], 2, ',', '.')?></td>
            </tr>
          <?php endforeach; ?>
        </tbody>
      </table>
      <button class="btn btn-success">Incluir na Cesta</button>
    </form>
  <?php endif; ?>
</div>
</body>
</html>

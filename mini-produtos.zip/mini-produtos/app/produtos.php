<?php 
require_once __DIR__ . '/../config/session.php'; 
require_login(); 
require __DIR__ . '/../config/db.php'; 
?>
<!doctype html>
<html lang="pt-br">
<head>
  <meta charset="utf-8">
  <title>Produtos</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
</head>
<body>
<?php include __DIR__ . '/partials/navbar.php'; ?>

<div class="container py-4">
  <h1 class="mb-3">Produtos</h1>

  <!-- Form com validação HTML5 -->
  <form id="formProd" class="row g-2 mb-3" novalidate>
    <div class="col-md-4">
      <input class="form-control" name="nome" placeholder="Nome"
             required minlength="2" maxlength="120">
      <div class="invalid-feedback">Informe um nome (mín. 2 caracteres).</div>
    </div>

    <div class="col-md-3">
      <input class="form-control" name="preco" type="number" step="0.01" min="0.01"
             placeholder="Preço" required>
      <div class="invalid-feedback">Preço deve ser maior que 0.</div>
    </div>

    <div class="col-md-3">
      <select class="form-select" name="fornecedor_id" required>
        <option value="">Fornecedor</option>
        <?php
          // Carrega fornecedores para o select
          $fs = $pdo->query('SELECT id, nome FROM fornecedores ORDER BY nome')->fetchAll();
          foreach ($fs as $f) {
            echo '<option value="'.$f['id'].'">'.htmlspecialchars($f['nome']).'</option>';
          }
        ?>
      </select>
      <div class="invalid-feedback">Selecione um fornecedor.</div>
    </div>

    <div class="col-md-2 d-grid">
      <button class="btn btn-primary">Salvar</button>
    </div>
  </form>

  <table class="table table-striped" id="tbl">
    <thead>
      <tr>
        <th>ID</th>
        <th>Nome</th>
        <th>Preço</th>
        <th>Fornecedor</th>
        <th>Ações</th>
      </tr>
    </thead>
    <tbody></tbody>
  </table>
</div>

<script>
const URL_LIST   = '../api/produtos/list.php';
const URL_CREATE = '../api/produtos/create.php';
const URL_DELETE = '../api/produtos/delete.php';

async function carregar(){
  const r = await fetch(URL_LIST);
  if (!r.ok) { alert('Listagem falhou ('+r.status+'): '+await r.text()); return; }
  const data = await r.json();
  const tb = document.querySelector('#tbl tbody');
  tb.innerHTML = '';
  for (const p of data){
    tb.innerHTML += `<tr>
      <td>${p.id}</td><td>${p.nome}</td><td>R$ ${parseFloat(p.preco).toFixed(2)}</td><td>${p.fornecedor ?? ''}</td>
      <td><button class="btn btn-sm btn-danger" onclick="excluir(${p.id})">Excluir</button></td>
    </tr>`;
  }
}

document.getElementById('formProd').addEventListener('submit', async (e)=>{
  e.preventDefault();
  const form = e.currentTarget;
  if (!form.checkValidity()) { form.classList.add('was-validated'); return; }
  const r = await fetch(URL_CREATE, { method:'POST', body:new FormData(form) });
  if (!r.ok) { alert('Criação falhou ('+r.status+'): '+await r.text()); return; }
  form.reset(); form.classList.remove('was-validated'); carregar();
});

async function excluir(id){
  if (!confirm('Excluir este produto?')) return;
  const fd = new FormData(); fd.append('id', id);
  const r = await fetch(URL_DELETE, { method:'POST', body: fd });
  if (!r.ok) { alert('Exclusão falhou ('+r.status+'): '+await r.text()); return; }
  carregar();
}

carregar();
</script>
</body>
</html>

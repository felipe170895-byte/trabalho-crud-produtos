<?php
require_once __DIR__ . '/../config/session.php';
require_login();
require __DIR__ . '/../config/db.php';

if (!empty($_GET['limpar'])) {
  unset($_SESSION['cesta']);
  header('Location: cesta.php');
  exit;
}

$itens = [];
$total = 0.0;

if (!empty($_SESSION['cesta'])) {
  $ids = array_keys($_SESSION['cesta']);           
  $placeholders = implode(',', array_fill(0, count($ids), '?'));
  $st = $pdo->prepare("SELECT id, nome, preco FROM produtos WHERE id IN ($placeholders)");
  $st->execute($ids);
  $itens = $st->fetchAll();

  foreach ($itens as $i) {
    $total += (float)$i['preco'];
  }
}

$qtd = count($itens);
?>
<!doctype html>
<html lang="pt-br">
<head>
  <meta charset="utf-8">
  <title>Cesta</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
</head>
<body>
<?php include __DIR__ . '/partials/navbar.php'; ?>
<div class="container py-4">
  <h1 class="mb-3">Cesta</h1>

  <?php if ($qtd === 0): ?>
    <div class="alert alert-info">Nenhum produto na cesta.</div>
    <a class="btn btn-link" href="selecionar.php">Selecionar produtos</a>
  <?php else: ?>
    <table class="table table-striped">
      <thead><tr><th>ID</th><th>Produto</th><th>Preço</th></tr></thead>
      <tbody>
        <?php foreach ($itens as $i): ?>
          <tr>
            <td><?=$i['id']?></td>
            <td><?=htmlspecialchars($i['nome'])?></td>
            <td>R$ <?=number_format((float)$i['preco'], 2, ',', '.')?></td>
          </tr>
        <?php endforeach; ?>
      </tbody>
    </table>

    <div class="alert alert-success">
      <strong>Total de produtos:</strong> <?=$qtd?> |
      <strong>Valor total:</strong> R$ <?=number_format($total, 2, ',', '.')?>
    </div>

    <a class="btn btn-outline-primary" href="selecionar.php">Voltar e alterar seleção</a>
    <a class="btn btn-outline-danger" href="cesta.php?limpar=1">Esvaziar cesta</a>
  <?php endif; ?>
</div>
</body>
</html>

<?php
require_once __DIR__ . '/Fornecedor.php';

class Produto {
  public function __construct(
    public ?int $id,
    public string $nome,
    public float $preco,
    public Fornecedor $fornecedor // relacionamento (composição)
  ) {}
}

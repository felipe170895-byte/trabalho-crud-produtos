<?php
class Fornecedor {
  public function __construct(
    public ?int $id,
    public string $nome,
    public string $cnpj,
    public ?string $telefone
  ) {}
}

<nav class="navbar navbar-expand-lg shadow-sm" style="background: linear-gradient(90deg, #0d6efd, #0a58ca);">
  <div class="container">
    <!-- logo / título -->
    <a class="navbar-brand fw-bold text-white" href="/mini-produtos/app/dashboard.php">
      <i class="bi bi-box-seam me-1"></i> Mini Produtos
    </a>

    <!-- botão mobile -->
    <button class="navbar-toggler text-white" type="button" data-bs-toggle="collapse" data-bs-target="#navMain">
      <span class="navbar-toggler-icon"></span>
    </button>

    <!-- links -->
    <div class="collapse navbar-collapse" id="navMain">
      <ul class="navbar-nav me-auto mb-2 mb-lg-0">
        <li class="nav-item"><a class="nav-link text-white" href="/mini-produtos/app/fornecedores.php"><i class="bi bi-truck"></i> Fornecedores</a></li>
        <li class="nav-item"><a class="nav-link text-white" href="/mini-produtos/app/produtos.php"><i class="bi bi-bag"></i> Produtos</a></li>
        <li class="nav-item"><a class="nav-link text-white" href="/mini-produtos/app/selecionar.php"><i class="bi bi-check2-square"></i> Selecionar</a></li>
        <li class="nav-item"><a class="nav-link text-white" href="/mini-produtos/app/cesta.php"><i class="bi bi-basket"></i> Cesta</a></li>
        <li class="nav-item"><a class="nav-link text-white" href="/mini-produtos/app/usuarios.php"><i class="bi bi-people"></i> Usuários</a></li>
      </ul>

      <!-- área do usuário -->
      <div class="d-flex align-items-center">
        <span class="text-white me-3">
          <i class="bi bi-person-circle"></i> <?=htmlspecialchars($_SESSION['user_name'] ?? 'Usuário')?>
        </span>
        <a class="btn btn-light btn-sm fw-semibold" href="/mini-produtos/auth/logout.php">
          <i class="bi bi-box-arrow-right"></i> Sair
        </a>
      </div>
    </div>
  </div>
</nav>
